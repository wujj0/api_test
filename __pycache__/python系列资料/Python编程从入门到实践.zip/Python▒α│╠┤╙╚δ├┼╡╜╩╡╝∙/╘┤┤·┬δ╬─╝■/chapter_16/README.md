Chapter 16
===

Pygal has been updated recently, which is a good thing; you're learning a library that's being steadily improved. If you're using the latest version of Pygal, you'll need to make some slight changes to the code in Chapter 16.

You can easily [install a version of Pygal](chapter_15/README.md#installing-pygal) that allows the code in the book to run exactly as it's written.