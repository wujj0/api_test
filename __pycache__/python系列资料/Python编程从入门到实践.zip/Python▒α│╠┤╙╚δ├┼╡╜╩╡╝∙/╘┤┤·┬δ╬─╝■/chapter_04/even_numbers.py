even_numbers = list(range(2,11,2)) 
print(even_numbers)
